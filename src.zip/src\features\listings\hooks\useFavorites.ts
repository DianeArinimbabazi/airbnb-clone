import toast from 'react-hot-toast';
import { useStore } from '../../../store/StoreContext';

export function useFavorites() {
  const { state, dispatch } = useStore();

  const toggle = (id: number, title: string) => {
    const isSaved = state.saved.includes(id);
    dispatch({ type: 'TOGGLE_FAVORITE', payload: id });
    if (isSaved) {
      toast(`Removed: ${title}`, { icon: '💔' });
    } else {
      toast(`Saved: ${title}`, { icon: '💜' });
    }
  };

  const isSaved = (id: number) => state.saved.includes(id);

  const count = state.saved.length;

  return { toggle, isSaved, count };
}