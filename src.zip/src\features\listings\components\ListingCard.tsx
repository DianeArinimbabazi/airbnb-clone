import { useNavigate } from 'react-router-dom';
import clsx from 'clsx';
import { format } from 'date-fns';
import { FaHeart, FaRegHeart, FaStar, FaMapMarkerAlt } from 'react-icons/fa';
import numeral from 'numeral';
import { motion } from 'framer-motion';
import { useFavorites } from '../hooks/useFavorites';
import type { Listing } from '../types';
import styles from './ListingCard.module.css';

interface ListingCardProps {
  listing: Listing;
}

export function ListingCard({ listing }: ListingCardProps) {
  const { title, location, price, rating, superhost, available, availableFrom, img, category } = listing;
  const { toggle, isSaved } = useFavorites();
  const saved = isSaved(listing.id);
  const navigate = useNavigate();

  return (
<motion.div
  className={clsx(styles.card, {
    [styles.saved]: saved,
    [styles.luxury]: price > 300,
    [styles.booked]: !available,
    [styles.superhost]: superhost,
  })}
  onClick={() => navigate(`/listings/${listing.id}`)}
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.4 }}
>
      <div className={styles.imgWrapper}>
        <img className={styles.img} src={img} alt={title} loading="lazy" />
        <span className={styles.category}>{category}</span>
        <button
          className={styles.heartBtn}
          onClick={() => toggle(listing.id, title)}
          aria-label="Toggle save"
        >
          {saved
            ? <FaHeart className={styles.heartSaved} />
            : <FaRegHeart className={styles.heartUnsaved} />}
        </button>
      </div>

      <div className={styles.body}>
        <div className={styles.topRow}>
          <h3 className={styles.title}>{title}</h3>
          <div className={styles.rating}>
            <FaStar />
            {numeral(rating).format('0.00')}
          </div>
        </div>

        <div className={styles.location}>
          <FaMapMarkerAlt />
          {location}
        </div>

        <div className={styles.meta}>
          {superhost && <span className={styles.badgeSuperhost}>Superhost</span>}
          {price > 300 && <span className={styles.badgeLuxury}>Luxury</span>}
          {available
            ? <span className={styles.badgeAvailable}>Available</span>
            : <span className={styles.badgeBooked}>Booked</span>}
        </div>

        <div className={styles.footer}>
          <div className={styles.price}>
            {numeral(price).format('$0,0')} <span>/ night</span>
          </div>
          <div className={styles.date}>
            From {format(new Date(availableFrom), 'MMM d, yyyy')}
          </div>
        </div>
      </div>
    </motion.div>
  );
}