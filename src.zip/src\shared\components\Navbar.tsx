import { NavLink, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import type { ReactElement } from 'react';
import { useAuth } from '../../features/auth/hooks/useAuth';
import { useStore } from '../../store/StoreContext';

type Panel = 'where' | 'when' | 'who' | null;
type Tab = 'homes' | 'experiences' | 'services';

const DESTINATIONS = [
  { icon: '📍', name: 'Nearby', sub: "Find what's around you" },
  { icon: '🏙️', name: 'Kigali, Rwanda', sub: 'Because your wishlist has stays in Kigali' },
  { icon: '🌊', name: 'Gisenyi, Rwanda', sub: 'For its lakeside allure' },
  { icon: '⛰️', name: 'Musanze, Rwanda', sub: 'For a mountain escape' },
  { icon: '🌿', name: 'Nyungwe, Rwanda', sub: 'For its forest beauty' },
  { icon: '🏞️', name: 'Kibuye, Rwanda', sub: 'For a trip by the lake' },
];

const MONTHS = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
];

export function Navbar() {
  const { isAuthenticated, logout } = useAuth();
  const { dispatch } = useStore();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<Tab>('homes');
  const [panel, setPanel] = useState<Panel>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [where, setWhere] = useState('');
  const [checkIn, setCheckIn] = useState<string>('');
  const [checkOut, setCheckOut] = useState<string>('');
  const [adults, setAdults] = useState(0);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);
  const [pets, setPets] = useState(0);

  const handleLogout = () => { logout(); navigate('/login'); };
  const togglePanel = (p: Panel) => { setMenuOpen(false); setPanel(prev => prev === p ? null : p); };

  const handleSearch = () => {
    setPanel(null);
    navigate(`/?search=${where}&tab=${activeTab}`);
  };

  const guestCount = adults + children;
  const whoLabel = guestCount > 0 ? `${guestCount} guest${guestCount > 1 ? 's' : ''}` : 'Add guests';

  const handleDayClick = (m: number, y: number, d: number) => {
    const dateStr = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    if (!checkIn || (checkIn && checkOut)) {
      setCheckIn(dateStr);
      setCheckOut('');
    } else {
      if (dateStr > checkIn) {
        setCheckOut(dateStr);
      } else {
        setCheckIn(dateStr);
        setCheckOut('');
      }
    }
  };

  const isSelected = (m: number, y: number, d: number) => {
    const dateStr = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    return dateStr === checkIn || dateStr === checkOut;
  };

  const isInRange = (m: number, y: number, d: number) => {
    if (!checkIn || !checkOut) return false;
    const dateStr = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    return dateStr > checkIn && dateStr < checkOut;
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [, m, d] = dateStr.split('-');
    return `${MONTHS[parseInt(m) - 1].slice(0, 3)} ${parseInt(d)}`;
  };

  const getDays = (m: number, y: number) => new Date(y, m + 1, 0).getDate();
  const getFirstDay = (m: number, y: number) => new Date(y, m, 1).getDay();

  const renderCalendar = (m: number, y: number) => {
    const days = getDays(m, y);
    const firstDay = getFirstDay(m, y);
    const cells: ReactElement[] = [];
    for (let i = 0; i < firstDay; i++) cells.push(<div key={`e${i}`} />);
    for (let d = 1; d <= days; d++) {
      const selected = isSelected(m, y, d);
      const inRange = isInRange(m, y, d);
      cells.push(
        <div
          key={d}
          onClick={() => handleDayClick(m, y, d)}
          style={{
            padding: '6px', textAlign: 'center', borderRadius: '50%',
            cursor: 'pointer', fontSize: '13px', transition: 'background 0.15s',
            background: selected ? '#9b8ec4' : inRange ? '#f0ebff' : 'transparent',
            color: selected ? '#fff' : inRange ? '#7c6fa8' : '#222',
            fontWeight: selected ? 700 : 400,
          }}
          onMouseEnter={e => {
            if (!selected) (e.currentTarget as HTMLDivElement).style.background = '#f5f3ff';
          }}
          onMouseLeave={e => {
            if (!selected) (e.currentTarget as HTMLDivElement).style.background = inRange ? '#f0ebff' : 'transparent';
          }}
        >
          {d}
        </div>
      );
    }
    return cells;
  };

  const currentYear = new Date().getFullYear();

  return (
    <>
      {/* Overlay to close panels and menu */}
      {(panel || menuOpen) && (
        <div
          onClick={() => { setPanel(null); setMenuOpen(false); }}
          style={{ position: 'fixed', inset: 0, zIndex: 98 }}
        />
      )}

      <nav style={{
        position: 'sticky', top: 0, zIndex: 99,
        background: '#fff', borderBottom: '1px solid #ede9fe',
        boxShadow: '0 2px 12px rgba(155,142,196,0.08)',
      }}>
        {/* Top row */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 32px', height: '64px',
        }}>
          <NavLink to="/" style={{ fontSize: '22px', fontWeight: 800, color: '#7c6fa8', textDecoration: 'none', flexShrink: 0 }}>
            💜 Diavela
          </NavLink>

          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            {(['homes', 'experiences', 'services'] as Tab[]).map((tab) => (
              <button key={tab} onClick={() => { setActiveTab(tab); navigate(`/?tab=${tab}`); }}
                style={{
                  background: 'none', border: 'none', padding: '8px 18px', borderRadius: '24px',
                  fontWeight: 600, fontSize: '15px', cursor: 'pointer', fontFamily: 'inherit',
                  color: activeTab === tab ? '#7c6fa8' : '#555',
                  borderBottom: activeTab === tab ? '2px solid #9b8ec4' : '2px solid transparent',
                  transition: 'all 0.2s', textTransform: 'capitalize',
                }}>
                {tab === 'homes' ? '🏠 Homes' : tab === 'experiences' ? '🎈 Experiences' : '🔔 Services'}
              </button>
            ))}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
            <NavLink to="/dashboard" style={({ isActive }) => ({
              padding: '8px 16px', borderRadius: '8px', fontWeight: 600, fontSize: '14px',
              textDecoration: 'none', color: isActive ? '#7c6fa8' : '#555',
              background: isActive ? '#f5f3ff' : 'transparent',
            })}>Dashboard</NavLink>

            <button onClick={() => { dispatch({ type: 'RESET' }); navigate('/'); }} style={{
              padding: '8px 14px', borderRadius: '8px', border: '1.5px solid #ddd',
              background: '#fff', fontWeight: 600, fontSize: '13px', color: '#888',
              cursor: 'pointer', fontFamily: 'inherit',
            }}>Clear All</button>

            {/* Hamburger + avatar menu */}
            <div style={{ position: 'relative' }}>
              <button
                onClick={(e) => { e.stopPropagation(); setPanel(null); setMenuOpen(prev => !prev); }}
                style={{
                  display: 'flex', alignItems: 'center', gap: '8px',
                  padding: '8px 12px', borderRadius: '24px',
                  border: '1.5px solid #ddd', background: '#fff',
                  cursor: 'pointer', fontFamily: 'inherit',
                  boxShadow: menuOpen ? '0 2px 8px rgba(0,0,0,0.12)' : 'none',
                }}
              >
                <span style={{ fontSize: '16px' }}>☰</span>
                <span style={{ fontSize: '20px' }}>👤</span>
              </button>

              {menuOpen && (
                <div
                  onClick={e => e.stopPropagation()}
                  style={{
                    position: 'absolute', top: 'calc(100% + 8px)', right: 0,
                    background: '#fff', borderRadius: '16px',
                    boxShadow: '0 8px 40px rgba(0,0,0,0.15)',
                    width: '280px', zIndex: 200, overflow: 'hidden',
                  }}
                >
                  {/* Help Center */}
                  <div
                    style={{ padding: '14px 20px', cursor: 'pointer', borderBottom: '1px solid #f0f0f0', display: 'flex', alignItems: 'center', gap: '12px' }}
                    onMouseEnter={e => (e.currentTarget.style.background = '#f9f9f9')}
                    onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
                  >
                    <span style={{ fontSize: '18px' }}>❓</span>
                    <p style={{ margin: 0, fontWeight: 400, fontSize: '14px', color: '#222' }}>Help Center</p>
                  </div>

                  {/* Become a host */}
                  <div
                    style={{ padding: '14px 20px', cursor: 'pointer', borderBottom: '1px solid #f0f0f0', display: 'flex', alignItems: 'flex-start', gap: '12px' }}
                    onMouseEnter={e => (e.currentTarget.style.background = '#f9f9f9')}
                    onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
                  >
                    <span style={{ fontSize: '18px', marginTop: '2px' }}>🏠</span>
                    <div>
                      <p style={{ margin: 0, fontWeight: 700, fontSize: '14px', color: '#222' }}>Become a host</p>
                      <p style={{ margin: '3px 0 0', fontSize: '12px', color: '#888', lineHeight: 1.4 }}>It's easy to start hosting and earn extra income.</p>
                    </div>
                  </div>

                  {/* Find a co-host */}
                  <div
                    style={{ padding: '14px 20px', cursor: 'pointer', borderBottom: '1px solid #f0f0f0', display: 'flex', alignItems: 'center', gap: '12px' }}
                    onMouseEnter={e => (e.currentTarget.style.background = '#f9f9f9')}
                    onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
                  >
                    <span style={{ fontSize: '18px' }}>🤝</span>
                    <p style={{ margin: 0, fontWeight: 400, fontSize: '14px', color: '#222' }}>Find a co-host</p>
                  </div>

                  {/* Gift cards */}
                  <div
                    style={{ padding: '14px 20px', cursor: 'pointer', borderBottom: '1px solid #f0f0f0', display: 'flex', alignItems: 'center', gap: '12px' }}
                    onMouseEnter={e => (e.currentTarget.style.background = '#f9f9f9')}
                    onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
                  >
                    <span style={{ fontSize: '18px' }}>🎁</span>
                    <p style={{ margin: 0, fontWeight: 400, fontSize: '14px', color: '#222' }}>Gift cards</p>
                  </div>

                  {/* Auth-dependent items */}
                  {isAuthenticated ? (
                    <>
                      <div
                        onClick={() => { setMenuOpen(false); navigate('/dashboard'); }}
                        style={{ padding: '14px 20px', cursor: 'pointer', borderBottom: '1px solid #f0f0f0', display: 'flex', alignItems: 'center', gap: '12px' }}
                        onMouseEnter={e => (e.currentTarget.style.background = '#f9f9f9')}
                        onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
                      >
                        <span style={{ fontSize: '18px' }}>📊</span>
                        <p style={{ margin: 0, fontWeight: 400, fontSize: '14px', color: '#222' }}>Dashboard</p>
                      </div>
                      <div
                        onClick={() => { setMenuOpen(false); handleLogout(); }}
                        style={{ padding: '14px 20px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '12px' }}
                        onMouseEnter={e => (e.currentTarget.style.background = '#f9f9f9')}
                        onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
                      >
                        <span style={{ fontSize: '18px' }}>🚪</span>
                        <p style={{ margin: 0, fontWeight: 400, fontSize: '14px', color: '#222' }}>Log out</p>
                      </div>
                    </>
                  ) : (
                    <div
                      onClick={() => { setMenuOpen(false); navigate('/login'); }}
                      style={{ padding: '14px 20px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '12px' }}
                      onMouseEnter={e => (e.currentTarget.style.background = '#f9f9f9')}
                      onMouseLeave={e => (e.currentTarget.style.background = '#fff')}
                    >
                      <span style={{ fontSize: '18px' }}>🔑</span>
                      <p style={{ margin: 0, fontWeight: 400, fontSize: '14px', color: '#222' }}>Log in or sign up</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Search bar */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '0 32px 16px', position: 'relative' }}>
          <div style={{
            display: 'flex', alignItems: 'center', background: '#fff',
            border: `1.5px solid ${panel ? '#9b8ec4' : '#e0d7f7'}`,
            borderRadius: '40px', boxShadow: '0 2px 16px rgba(155,142,196,0.15)',
            width: '100%', maxWidth: '720px', position: 'relative',
          }}>
            <div onClick={() => togglePanel('where')} style={{
              flex: 1, padding: '12px 24px', borderRight: '1px solid #e0d7f7', cursor: 'pointer',
              background: panel === 'where' ? '#f5f3ff' : 'transparent', borderRadius: '40px 0 0 40px',
            }}>
              <p style={{ margin: 0, fontSize: '11px', fontWeight: 700, color: '#222' }}>Where</p>
              <p style={{ margin: 0, fontSize: '13px', color: where ? '#222' : '#888' }}>{where || 'Search destinations'}</p>
            </div>

            <div onClick={() => togglePanel('when')} style={{
              flex: 1, padding: '12px 24px', borderRight: '1px solid #e0d7f7', cursor: 'pointer',
              background: panel === 'when' ? '#f5f3ff' : 'transparent',
            }}>
              <p style={{ margin: 0, fontSize: '11px', fontWeight: 700, color: '#222' }}>When</p>
              <p style={{ margin: 0, fontSize: '13px', color: checkIn ? '#222' : '#888' }}>
                {checkIn ? `${formatDate(checkIn)}${checkOut ? ` → ${formatDate(checkOut)}` : ' → checkout'}` : 'Add dates'}
              </p>
            </div>

            <div onClick={() => togglePanel('who')} style={{
              flex: 1, padding: '12px 24px', cursor: 'pointer',
              background: panel === 'who' ? '#f5f3ff' : 'transparent',
            }}>
              <p style={{ margin: 0, fontSize: '11px', fontWeight: 700, color: '#222' }}>Who</p>
              <p style={{ margin: 0, fontSize: '13px', color: guestCount > 0 ? '#222' : '#888' }}>{whoLabel}</p>
            </div>

            <div style={{ padding: '8px 12px 8px 0' }}>
              <button onClick={handleSearch} style={{
                background: '#9b8ec4', border: 'none', borderRadius: '50%',
                width: '44px', height: '44px', display: 'flex',
                alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '18px',
              }}>🔍</button>
            </div>
          </div>

          {/* WHERE PANEL */}
          {panel === 'where' && (
            <div style={{
              position: 'absolute', top: '100%', left: '50%', transform: 'translateX(-50%)',
              marginTop: '8px', background: '#fff', borderRadius: '20px',
              boxShadow: '0 8px 40px rgba(0,0,0,0.15)', width: '480px', zIndex: 200, padding: '24px',
            }}>
              <p style={{ fontSize: '13px', fontWeight: 700, color: '#444', margin: '0 0 16px' }}>Suggested destinations</p>
              {DESTINATIONS.map((d) => (
                <div key={d.name} onClick={() => { setWhere(d.name); setPanel(null); }}
                  style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '12px', borderRadius: '12px', cursor: 'pointer', transition: 'background 0.15s' }}
                  onMouseEnter={e => (e.currentTarget.style.background = '#f5f3ff')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >
                  <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: '#f0ebff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', flexShrink: 0 }}>{d.icon}</div>
                  <div>
                    <p style={{ margin: 0, fontWeight: 600, fontSize: '15px', color: '#222' }}>{d.name}</p>
                    <p style={{ margin: 0, fontSize: '13px', color: '#888' }}>{d.sub}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* WHEN PANEL */}
          {panel === 'when' && (
            <div style={{
              position: 'absolute', top: '100%', left: '50%', transform: 'translateX(-50%)',
              marginTop: '8px', background: '#fff', borderRadius: '20px',
              boxShadow: '0 8px 40px rgba(0,0,0,0.15)', width: '700px', zIndex: 200,
              padding: '24px', maxHeight: '520px', overflowY: 'auto',
            }}>
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
                <div style={{ display: 'flex', background: '#f0f0f0', borderRadius: '24px', padding: '4px', gap: '4px' }}>
                  {['Dates', 'Flexible'].map(t => (
                    <button key={t} style={{
                      padding: '8px 24px', borderRadius: '20px', border: 'none',
                      background: t === 'Dates' ? '#fff' : 'transparent',
                      fontWeight: 600, fontSize: '14px', cursor: 'pointer', fontFamily: 'inherit', color: '#222',
                      boxShadow: t === 'Dates' ? '0 1px 4px rgba(0,0,0,0.1)' : 'none',
                    }}>{t}</button>
                  ))}
                </div>
              </div>

              {(checkIn || checkOut) && (
                <div style={{ display: 'flex', justifyContent: 'center', gap: '32px', marginBottom: '16px', padding: '12px 24px', background: '#f5f3ff', borderRadius: '12px' }}>
                  <div style={{ textAlign: 'center' }}>
                    <p style={{ fontSize: '11px', fontWeight: 700, color: '#9b8ec4', margin: '0 0 2px', textTransform: 'uppercase' }}>Check-in</p>
                    <p style={{ fontSize: '16px', fontWeight: 700, color: '#222', margin: 0 }}>{checkIn ? formatDate(checkIn) : '—'}</p>
                  </div>
                  <div style={{ width: '1px', background: '#ddd' }} />
                  <div style={{ textAlign: 'center' }}>
                    <p style={{ fontSize: '11px', fontWeight: 700, color: '#9b8ec4', margin: '0 0 2px', textTransform: 'uppercase' }}>Check-out</p>
                    <p style={{ fontSize: '16px', fontWeight: 700, color: '#222', margin: 0 }}>{checkOut ? formatDate(checkOut) : '—'}</p>
                  </div>
                  <button onClick={() => { setCheckIn(''); setCheckOut(''); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9b8ec4', fontSize: '13px', fontWeight: 600, fontFamily: 'inherit', alignSelf: 'center' }}>Clear</button>
                </div>
              )}

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '32px' }}>
                {MONTHS.map((monthName, idx) => (
                  <div key={idx}>
                    <p style={{ fontWeight: 700, fontSize: '15px', textAlign: 'center', margin: '0 0 12px', color: '#222' }}>{monthName} {currentYear}</p>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '2px', textAlign: 'center' }}>
                      {['S','M','T','W','T','F','S'].map((d, i) => (
                        <div key={i} style={{ fontSize: '11px', fontWeight: 600, color: '#aaa', padding: '3px' }}>{d}</div>
                      ))}
                      {renderCalendar(idx, currentYear)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* WHO PANEL */}
          {panel === 'who' && (
            <div style={{
              position: 'absolute', top: '100%', right: 'calc(50% - 360px)', marginTop: '8px',
              background: '#fff', borderRadius: '20px', boxShadow: '0 8px 40px rgba(0,0,0,0.15)',
              width: '380px', zIndex: 200, padding: '24px',
            }}>
              {[
                { label: 'Adults', sub: 'Ages 13 or above', val: adults, set: setAdults },
                { label: 'Children', sub: 'Ages 2 – 12', val: children, set: setChildren },
                { label: 'Infants', sub: 'Under 2', val: infants, set: setInfants },
                { label: 'Pets', sub: 'Bringing a service animal?', val: pets, set: setPets },
              ].map(({ label, sub, val, set }) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 0', borderBottom: label !== 'Pets' ? '1px solid #f0f0f0' : 'none' }}>
                  <div>
                    <p style={{ margin: 0, fontWeight: 600, fontSize: '15px', color: '#222' }}>{label}</p>
                    <p style={{ margin: 0, fontSize: '13px', color: '#888' }}>{sub}</p>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                    <button onClick={() => set((v: number) => Math.max(0, v - 1))} style={{ width: '32px', height: '32px', borderRadius: '50%', border: '1.5px solid #ddd', background: '#fff', cursor: 'pointer', fontSize: '16px', fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'inherit' }}>−</button>
                    <span style={{ fontWeight: 600, fontSize: '15px', minWidth: '20px', textAlign: 'center' }}>{val}</span>
                    <button onClick={() => set((v: number) => v + 1)} style={{ width: '32px', height: '32px', borderRadius: '50%', border: '1.5px solid #ddd', background: '#fff', cursor: 'pointer', fontSize: '16px', fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'inherit' }}>+</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </nav>
    </>
  );
}