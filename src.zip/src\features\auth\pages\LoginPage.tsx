import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useNavigate, Link } from 'react-router-dom';

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password);
    navigate('/dashboard');
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      fontFamily: 'inherit',
      justifyContent: 'center',
      alignItems: 'center',
      background: 'linear-gradient(135deg, #f5f3ff 0%, #ede9fe 100%)',
    }}>
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        padding: '60px 64px',
        background: '#fff',
        width: '100%',
        maxWidth: '520px',
        borderRadius: '20px',
        boxShadow: '0 8px 40px rgba(155,142,196,0.18)',
        margin: '40px',
      }}>
        <div style={{ marginBottom: '40px' }}>
          <h1 style={{ fontSize: '28px', fontWeight: 800, color: '#222', margin: '0 0 6px' }}>
            Welcome back! Please{' '}
            <span style={{ color: '#9b8ec4', fontStyle: 'italic' }}>Sign in</span>{' '}
            to continue.
          </h1>
          <p style={{ fontSize: '14px', color: '#888', margin: 0 }}>
            Unlock a world of exclusive homes, enjoy special offers, and be the first to discover new listings by joining our community!
          </p>
        </div>

        <button style={{
          width: '100%', padding: '13px', border: '1.5px solid #ddd',
          borderRadius: '8px', background: '#111', color: '#fff',
          fontSize: '15px', fontWeight: 600, cursor: 'pointer',
          fontFamily: 'inherit', marginBottom: '12px',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px',
        }}>
          🍎 Sign in with Apple
        </button>

        <button style={{
          width: '100%', padding: '13px', border: '1.5px solid #ddd',
          borderRadius: '8px', background: '#fff', color: '#333',
          fontSize: '15px', fontWeight: 600, cursor: 'pointer',
          fontFamily: 'inherit', marginBottom: '20px',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px',
        }}>
          <span style={{ fontSize: '18px' }}>G</span> Sign in with Google
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
          <div style={{ flex: 1, height: '1px', background: '#eee' }} />
          <span style={{ color: '#aaa', fontSize: '13px' }}>Or</span>
          <div style={{ flex: 1, height: '1px', background: '#eee' }} />
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#444', marginBottom: '6px' }}>
              Enter Email *
            </label>
            <input
              type="email" required value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              style={{
                width: '100%', padding: '12px 16px', border: '1.5px solid #ddd',
                borderRadius: '8px', fontSize: '14px', outline: 'none',
                fontFamily: 'inherit', boxSizing: 'border-box',
              }}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: '#444', marginBottom: '6px' }}>
              Password *
            </label>
            <input
              type="password" required value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              style={{
                width: '100%', padding: '12px 16px', border: '1.5px solid #ddd',
                borderRadius: '8px', fontSize: '14px', outline: 'none',
                fontFamily: 'inherit', boxSizing: 'border-box',
              }}
            />
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <input type="checkbox" id="remember" />
            <label htmlFor="remember" style={{ fontSize: '13px', color: '#666' }}>Remember me next time</label>
          </div>

          <button
            type="submit"
            style={{
              width: '100%', padding: '14px',
              background: '#9b8ec4', color: '#fff', border: 'none',
              borderRadius: '8px', fontSize: '16px', fontWeight: 700,
              cursor: 'pointer', fontFamily: 'inherit', marginTop: '4px',
            }}
          >
            Sign In
          </button>
        </form>

        <p style={{ textAlign: 'center', marginTop: '20px', fontSize: '14px', color: '#888' }}>
          Don't have an account?{' '}
          <Link to="/signup" style={{ color: '#9b8ec4', fontWeight: 700, textDecoration: 'none' }}>
            Sign Up
          </Link>
        </p>
        <p style={{ textAlign: 'center', marginTop: '8px', fontSize: '13px' }}>
          <Link to="/" style={{ color: '#9b8ec4', textDecoration: 'none' }}>Remind Password</Link>
        </p>
      </div>
      <p style={{ textAlign: 'center', marginTop: '24px', fontSize: '14px', color: '#717171' }}>
  Don't have an account?{' '}
  <Link to="/signup" style={{ color: '#9b8ec4', fontWeight: 700 }}>
    Sign up
  </Link>
</p>
    </div>
  );
}