import { useEffect, useRef } from 'react';
import { debounce } from 'lodash';
import { useStore } from '../../../store/StoreContext';

export function SearchBar() {
  const { dispatch } = useStore();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleChange = debounce((value: string) => {
    dispatch({ type: 'SET_FILTER', payload: value });
  }, 300);

  return (
    <input
      ref={inputRef}
      className="search-bar"
      type="text"
      placeholder="Search listings..."
      onChange={(e) => handleChange(e.target.value)}
    />
  );
}