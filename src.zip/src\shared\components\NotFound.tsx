 import { Link } from 'react-router-dom';

export function NotFound() {
  return (
    <div style={{
      minHeight: '80vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      padding: '24px',
    }}>
      <p style={{ fontSize: '80px', margin: '0 0 16px' }}>🏚️</p>
      <h1 style={{ fontSize: '48px', fontWeight: 800, color: '#9b8ec4', margin: '0 0 8px' }}>
        404
      </h1>
      <p style={{ fontSize: '20px', fontWeight: 600, color: '#222', margin: '0 0 8px' }}>
        Page not found
      </p>
      <p style={{ fontSize: '15px', color: '#888', margin: '0 0 32px' }}>
        The page you are looking for doesn't exist.
      </p>
      <Link
        to="/"
        style={{
          background: '#9b8ec4',
          color: '#fff',
          padding: '12px 28px',
          borderRadius: '10px',
          fontWeight: 700,
          fontSize: '15px',
          textDecoration: 'none',
        }}
      >
        Back to Home
      </Link>
    </div>
  );
}
