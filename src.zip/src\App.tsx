import { lazy, Suspense, useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import { ListingsPage } from './features/listings';
import { LoginPage, SignupPage } from './features/auth';
import { Navbar } from './shared/components/Navbar';
import { ProtectedRoute } from './shared/components/ProtectedRoute';
import { NotFound } from './shared/components/NotFound';
import { Spinner } from './shared/components/Spinner';

const ListingDetail = lazy(() =>
  import('./features/listings/pages/ListingDetail').then((m) => ({ default: m.ListingDetail }))
);

const DashboardPage = lazy(() =>
  import('./features/auth/pages/DashboardPage').then((m) => ({ default: m.DashboardPage }))
);

function App() {
  const location = useLocation();

  useEffect(() => {
    NProgress.start();
    const timer = setTimeout(() => NProgress.done(), 100);
    return () => clearTimeout(timer);
  }, [location]);

  return (
    <>
      <Navbar />
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route path="/" element={<ListingsPage />} />
          <Route path="/listings/:id" element={<ListingDetail />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </>
  );
}

export default App;