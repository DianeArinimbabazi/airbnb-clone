  import { useParams, useNavigate } from 'react-router-dom';
import { useStore } from '../../../store/StoreContext';
import { useFavorites } from '../hooks/useFavorites';
import { FaStar, FaMapMarkerAlt, FaHeart, FaRegHeart } from 'react-icons/fa';
import dayjs from 'dayjs';

export function ListingDetail() {
  const { id } = useParams();
  const { state } = useStore();
  const { toggle, isSaved } = useFavorites();
  const navigate = useNavigate();

  const listing = state.listings.find((l) => l.id === Number(id));

  if (!listing) {
    return (
      <div style={{ textAlign: 'center', padding: '80px 24px' }}>
        <p style={{ fontSize: '48px' }}>🏚️</p>
        <h2 style={{ color: '#222', fontSize: '24px' }}>Listing not found</h2>
        <button
          onClick={() => navigate(-1)}
          style={{
            marginTop: '16px',
            background: '#9b8ec4',
            color: '#fff',
            border: 'none',
            borderRadius: '10px',
            padding: '12px 24px',
            fontWeight: 700,
            cursor: 'pointer',
            fontFamily: 'inherit',
            fontSize: '15px',
          }}
        >
          Go Back
        </button>
      </div>
    );
  }

  const saved = isSaved(listing.id);

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '40px 24px 80px' }}>
      <button
        onClick={() => navigate(-1)}
        style={{
          background: 'none',
          border: '1.5px solid #ddd',
          borderRadius: '10px',
          padding: '10px 20px',
          fontWeight: 600,
          fontSize: '14px',
          color: '#555',
          cursor: 'pointer',
          fontFamily: 'inherit',
          marginBottom: '24px',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
        }}
      >
        ← Back
      </button>

      <div style={{
        borderRadius: '20px',
        overflow: 'hidden',
        boxShadow: '0 8px 40px rgba(155,142,196,0.18)',
      }}>
        <div style={{ position: 'relative', height: '420px' }}>
          <img
            src={listing.img}
            alt={listing.title}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
          <button
            onClick={() => toggle(listing.id, listing.title)}
            style={{
              position: 'absolute',
              top: '16px',
              right: '16px',
              background: 'rgba(255,255,255,0.9)',
              border: 'none',
              borderRadius: '50%',
              width: '44px',
              height: '44px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              fontSize: '20px',
            }}
          >
            {saved ? <FaHeart color="#9b8ec4" /> : <FaRegHeart color="#555" />}
          </button>
        </div>

        <div style={{ padding: '32px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px' }}>
            <h1 style={{ fontSize: '28px', fontWeight: 800, color: '#222', margin: 0 }}>
              {listing.title}
            </h1>
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', flexShrink: 0 }}>
              <FaStar color="#9b8ec4" />
              <span style={{ fontWeight: 700, fontSize: '16px' }}>{listing.rating}</span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '10px', color: '#717171' }}>
            <FaMapMarkerAlt color="#9b8ec4" />
            <span>{listing.location}</span>
          </div>

          <div style={{ display: 'flex', gap: '10px', marginTop: '16px', flexWrap: 'wrap' }}>
            {listing.superhost && (
              <span style={{
                background: '#f5f3ff', color: '#7c6fa8', border: '1px solid #c4b5fd',
                borderRadius: '20px', padding: '4px 12px', fontSize: '13px', fontWeight: 600,
              }}>
                Superhost
              </span>
            )}
            <span style={{
              background: listing.available ? '#eafaf1' : '#f5f5f5',
              color: listing.available ? '#1a7f45' : '#888',
              border: `1px solid ${listing.available ? '#abebc6' : '#ddd'}`,
              borderRadius: '20px', padding: '4px 12px', fontSize: '13px', fontWeight: 600,
            }}>
              {listing.available ? 'Available' : 'Booked'}
            </span>
            <span style={{
              background: '#f0f0f0', color: '#555',
              borderRadius: '20px', padding: '4px 12px', fontSize: '13px', fontWeight: 600,
              textTransform: 'capitalize',
            }}>
              {listing.category}
            </span>
          </div>

          <div style={{
            marginTop: '32px',
            paddingTop: '24px',
            borderTop: '1px solid #f0f0f0',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <div>
              <p style={{ fontSize: '28px', fontWeight: 800, color: '#222', margin: 0 }}>
                ${listing.price} <span style={{ fontSize: '16px', fontWeight: 400, color: '#717171' }}>/ night</span>
              </p>
              <p style={{ fontSize: '14px', color: '#aaa', margin: '4px 0 0' }}>
                Available from {dayjs(listing.availableFrom).format('MMMM D, YYYY')}
              </p>
            </div>
            <button style={{
              background: '#9b8ec4',
              color: '#fff',
              border: 'none',
              borderRadius: '12px',
              padding: '14px 32px',
              fontSize: '16px',
              fontWeight: 700,
              cursor: 'pointer',
              fontFamily: 'inherit',
            }}>
              Reserve
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
