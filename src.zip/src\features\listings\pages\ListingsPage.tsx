import { useMemo, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../store/StoreContext';
import { useListings } from '../hooks/useListings';
import { useFavorites } from '../hooks/useFavorites';
import { ListingCard } from '../components/ListingCard';
import { SearchBar } from '../components/SearchBar';
import { SavedBadge } from '../components/SavedBadge';
import { SavedListings } from '../components/SavedListings';
import { Spinner } from '../../../shared/components/Spinner';
import './ListingsPage.css';

export function ListingsPage() {
  useListings();
  const { state } = useStore();
  const { count } = useFavorites();
  const [savedOnly, setSavedOnly] = useState(false);
  const navigate = useNavigate();

  const filtered = useMemo(() => {
    return state.listings
      .filter(({ title, location }) => {
        const q = state.filter.toLowerCase();
        return title.toLowerCase().includes(q) || location.toLowerCase().includes(q);
      })
      .filter((listing) => (savedOnly ? state.saved.includes(listing.id) : true));
  }, [state.listings, state.filter, state.saved, savedOnly]);

  const handleNavigate = useCallback((id: number) => {
    navigate(`/listings/${id}`);
  }, [navigate]);

  return (
    <div className="listings-page">
      <header className="listings-header">
        <div className="listings-header__top">
          <div>
            <h1 className="listings-title">Popular homes in Kigali</h1>
            <p className="listings-subtitle">Discover handpicked homes across Rwanda</p>
          </div>
          <SavedBadge count={count} />
        </div>
        <div className="listings-controls">
          <SearchBar />
          <button
            className={`saved-toggle ${savedOnly ? 'saved-toggle--active' : ''}`}
            onClick={() => setSavedOnly((prev) => !prev)}
          >
            {savedOnly ? 'Show All' : 'Saved Only'}
          </button>
        </div>
      </header>

      <SavedListings />

      {state.loading ? (
        <Spinner />
      ) : (
        <>
          <p className="results-count">
            {filtered.length} {filtered.length === 1 ? 'listing' : 'listings'} found
          </p>

          {filtered.length > 0 ? (
            <div className="listings-grid">
              {filtered.map((listing) => (
                <div
                  key={listing.id}
                  style={{ cursor: 'pointer' }}
                  onClick={() => handleNavigate(listing.id)}
                >
                  <ListingCard listing={listing} />
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <p className="empty-state__icon">🏡</p>
              <p className="empty-state__title">No listings found</p>
              <p className="empty-state__sub">Try a different search or clear your filters.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}