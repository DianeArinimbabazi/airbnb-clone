import { createContext, useState } from 'react';
import type { ReactNode } from 'react';
import type { AuthContextValue } from '../types';

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [email, setEmail] = useState<string | null>(null);

  const login = (email: string, _password: string) => {
    setIsAuthenticated(true);
    setEmail(email);
  };

  const logout = () => {
    setIsAuthenticated(false);
    setEmail(null);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, email, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export { AuthContext };  
